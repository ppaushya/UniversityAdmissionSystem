package org.uas.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.uas.model.Application;
import org.uas.model.Participant;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;
import org.uas.model.Role;
import org.uas.model.Status;
import org.uas.model.Users;



public class UAS_Dao_Impl implements I_UAS_Dao{

	final static Logger logger=Logger.getLogger(UAS_Dao_Impl.class);
	
	public Connection getConnection() {
		Connection connection = null;
		try {
		Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/case_study", "root", "India123");
			return connection;
			
		} catch (ClassNotFoundException | SQLException e) {
			/*System.out.println(e.toString());
			e.printStackTrace();*/
			logger.error(e);
		}
		return null;
	}
	
	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		//Call Program Offered DAO
		ProgramsOfferedDao programOfferedDao=new ProgramsOfferedDao();
		return programOfferedDao.getAllProgramsOffered();
	}
	
	@Override
	public Application apply(Application application) {
		//Call Program Application DAO
		ApplyDao applyDao=new ApplyDao();
		return applyDao.apply(application);
	}
	
	@Override
	public String getStatus(int appId) {
		//Call Application DAO
		GetStatusDao getStatusDao=new GetStatusDao();
		return getStatusDao.getStatus(appId);
	}

	@Override
	public List<Application> getAllApplicants(int programId) {
		//Call Application DAO
		ApplicationDao applicationDao=new ApplicationDao();
		return applicationDao.getAllApplicants(programId);
	}
	
	@Override
	public boolean updateApplicationStatus(Application application) {
		//Call Application DAO
		UpdateApplicationStatusDao updateApplicationDao=new UpdateApplicationStatusDao();
		 return(updateApplicationDao.updateApplicationStatus(application));
	}
	
	@Override
	public List<Users> getUserDetails() {
		//Call User DAO
		UsersDao usersDao=new UsersDao();
		return usersDao.getUserDetails();
	}
	
	@Override
	public boolean createParticipant(Participant participant) {
		//Call Participant DAO
		CreateParticipantsDao participantDao=new CreateParticipantsDao();
		return(participantDao.createParticipant(participant));
	}

	@Override
	public boolean isValidProgram(int programId) {
		//Call Program Scheduled DAO
		ProgramScheduleDao programScheduleDao=new ProgramScheduleDao();
		return(programScheduleDao.isValidProgram(programId));
	}

	@Override
	public String getEligibilityCriteria(int programId) {
		//Call Program Scheduled DAO
		ProgramsOfferedDao programOfferedDao=new ProgramsOfferedDao();
		return programOfferedDao.getEligibilityCriteria(programId);
	}

	@Override
	public List<ProgramsSchedule> getProgramSchedules() {
		//Call Program Scheduled DAO
		ProgramScheduleDao program_schedule_dao=new ProgramScheduleDao();
		return program_schedule_dao.getProgramSchedules();
	}

}
