package org.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.uas.model.Application;

public class GetStatusDao {
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();
	
	
	//Get Status from application table
		public String getStatus(int appId) {
			
			String sql="select status from application where application_id=?";
			try(Connection connection=uasDao.getConnection())
			{
				PreparedStatement pst=connection.prepareStatement(sql);
					pst.setInt(1, appId);
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						return rs.getString(1);
					}
					
			} catch (SQLException e) {
				uasDao.logger.error("Error occure while fetching status of application"+e);
			}
			
			return null;
		}
		

}
