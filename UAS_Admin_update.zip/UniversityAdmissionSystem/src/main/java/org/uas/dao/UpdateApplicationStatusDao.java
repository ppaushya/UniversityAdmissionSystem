package org.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.uas.model.Application;
import org.uas.model.Status;

public class UpdateApplicationStatusDao {
	
	
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();
	
	
	//Update the date of Interview and the status of the applicant based upon the application object passed
	
public boolean updateApplicationStatus(Application application) {
		
		String sql="update application set status=?, date_of_interview=? where application_id=?";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setString(1,application.getStatus().toString());
			if(application.getStatus()==Status.REJECTED || application.getStatus()==Status.CONFIRMED )
			{
				pst.setDate(2, null);
			}
			else
			{
			pst.setDate(2, Date.valueOf(application.getDateOfInterview()));
			}
			pst.setInt(3, application.getApplicationId());
			
			int count=pst.executeUpdate();
			if(count>0)
			{
				uasDao.logger.info("Application record updated");
				return true;
			}
			else
			{
				uasDao.logger.info("Application Update failed");
				return false;
				
			}
		
		} catch (SQLException e) {
			uasDao.logger.error("Error occured while updating application record"+e);
		}
		return false;
	}
	

}
