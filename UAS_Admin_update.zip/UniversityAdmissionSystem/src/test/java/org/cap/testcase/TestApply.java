package org.cap.testcase;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.uas.dao.ApplicationDao;
import org.uas.dao.I_UAS_Dao;
import org.uas.model.Application;
import org.uas.model.Participant;
import org.uas.model.Status;
import org.uas.service.UAS_Service_Impl;
import org.uas.view.InvalidMarksException;


public class TestApply {

	
	@Mock
	private I_UAS_Dao applicationdao;
	
	private UAS_Service_Impl service;
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		service = new UAS_Service_Impl(applicationdao);
	}
	
	
	
	@Test(expected=InvalidMarksException.class)
	public void test_invalid_marks() throws InvalidMarksException
	{
		int marks=-100;
		
		
		service.isVAlidMarks(marks);
		
	}
	
	//Mockito verification for adding applicant
	@Test
	public void test_acc()
	{
		Application application1=new Application();
	
   
		application1.setApplicationId(1);
		application1.setFullName("akhil");
		application1.setDateOfBirth(LocalDate.of(2000, 10, 10));
		application1.setHighestQualification("12th");
		application1.setMarksObtained(100);
		application1.setGoals("towin");
		application1.setEmailId("akhil@gmail");
		application1.setScheduledProgramId(1001);
		application1.setStatus(Status.APPLIED);
		application1.setDateOfInterview(LocalDate.of(2018, 10, 10));
	    
	    Mockito.when(applicationdao.apply(application1)).thenReturn(application1);
	    
	    
	    service.apply(application1);
	    
	    Mockito.verify(applicationdao).apply(application1);
	    
	    
	}
	
	
	//Mockito verification for createParticipant
	@Test
	public void test_participants()
	{
		Participant participant=new Participant();
		participant.setRollNo(111);
		
		Application application1=new Application();
		
		   
		application1.setApplicationId(1);
		application1.setFullName("Annapoorna");
		application1.setDateOfBirth(LocalDate.of(1996, 10, 10));
		application1.setHighestQualification("UG");
		application1.setMarksObtained(100);
		application1.setGoals("to win");
		application1.setEmailId("annapoorna@gmail.com");
		application1.setScheduledProgramId(1001);
		application1.setStatus(Status.APPLIED);
		application1.setDateOfInterview(LocalDate.of(2018, 10, 10));
		participant.setScheduledProgramId(application1.getScheduledProgramId());
		participant.setApplication(application1);
		participant.setEmailId(application1.getEmailId());
		
		
		Mockito.when(applicationdao.createParticipant(participant)).thenReturn(true);
		
		service.createParticipant(participant);
		
		Mockito.verify(applicationdao).createParticipant(participant);
		
	}
	
	
	
	//Test case for updateApplicationStatus
	@Test
	public void test_update_Status()
	{

		Application application1=new Application();
		
		   
		application1.setApplicationId(1);
		application1.setFullName("Annapoorna");
		application1.setDateOfBirth(LocalDate.of(1996, 10, 10));
		application1.setHighestQualification("UG");
		application1.setMarksObtained(100);
		application1.setGoals("to win");
		application1.setEmailId("annapoorna@gmail.com");
		application1.setScheduledProgramId(1001);
		application1.setStatus(Status.APPLIED);
		application1.setDateOfInterview(LocalDate.of(2018, 10, 10));
		
		  Mockito.when(applicationdao.updateApplicationStatus(application1)).thenReturn(true);
		  
		    
		    
		    service.apply(application1);
		    
		    Mockito.verify(applicationdao).apply(application1);
		
	}
	
}
