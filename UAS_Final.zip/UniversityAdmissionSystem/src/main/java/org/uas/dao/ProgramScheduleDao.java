package org.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.uas.model.ProgramsSchedule;

public class ProgramScheduleDao {
	
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();

	//Return boolean if program exist or not
	public  boolean isValidProgram(int programId) {

		String sql="select * from programs_scheduled where scheduled_program_id=? ";
		
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			
			pst.setInt(1, programId);
			ResultSet rs=pst.executeQuery();
		
			if(rs.next())
			{
				return true;
			}
			else
			{}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		}
	
	
		//Get all Scheduled Programs list
public List<ProgramsSchedule> getProgramSchedules() {
		
		List<ProgramsSchedule> programs= new ArrayList<>();
		
		String sql="select * from programs_scheduled";

		try(Connection connection1=uasDao.getConnection())
		{
			PreparedStatement pst=connection1.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ProgramsSchedule ps=new ProgramsSchedule();
				ps.setScheduleProgramId(rs.getInt(1));
				ps.setProgramName(rs.getString(2));
				ps.setLocation(rs.getString(3));
				ps.setStartDate(rs.getDate(4).toLocalDate());
				ps.setEndDate(rs.getDate(5).toLocalDate());
				ps.setSessionPerWeek(rs.getInt(6));
				programs.add(ps);
			}
			
			return programs;
			
		} catch (SQLException e) {
			uasDao.logger.error("Error occured"+e);
		}
		return null;
		
	}
}
