package org.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.uas.model.Application;
import org.uas.model.Status;

public class ApplyDao {
	
	
	
UAS_Dao_Impl uasDao=new UAS_Dao_Impl();
	
	
	//Create new applicant in application table 
	public Application apply(Application application) {
		Application application1=new Application();
		String sql="insert into application(full_name, date_of_birth, highest_qualification, marks_obtained, goals, email_id, scheduled_program_id, status) "
				+ "values(?,?,?,?,?,?,?,?)";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
				pst.setString(1, application.getFullName());
				pst.setDate(2,Date.valueOf(application.getDateOfBirth()));
				pst.setString(3, application.getHighestQualification());
				pst.setInt(4, application.getMarksObtained());
				pst.setString(5, application.getGoals());
				pst.setString(6, application.getEmailId());
				pst.setInt(7, application.getScheduledProgramId());
				pst.setString(8,application.getStatus().toString());
				
			
			int flag=pst.executeUpdate();
			if(flag>0)
			{
				
				uasDao.logger.info("Application Record inserted successfully");
				String sql1="select application_id, scheduled_program_id, status from application";
				PreparedStatement pst1=connection.prepareStatement(sql1);
				
				ResultSet rs=pst1.executeQuery();
				
				while(rs.next())
				{
					application1.setApplicationId(rs.getInt(1));
					application1.setScheduledProgramId(rs.getInt(2));
					application1.setStatus(Status.valueOf(rs.getString(3)));
					
				}
				return application1;
			}
			
		} catch (SQLException e) {
			uasDao.logger.error("Error occured while inserting application record"+e);
		}
		
		return null;
	}

}
