package org.uas.view;

import java.util.Scanner;

public class BootClass {
	
	static Scanner scr=new Scanner(System.in);
	public static void main(String[] args) throws InterruptedException, InvalidMarksException
	{
		//Heading Design Generation 
		Utility.generateDesign();
		
		
		String choice;
		do {
		System.out.println("*--------------------*");
		System.out.println(" Apply or MAC Login? ");
		System.out.println("*--------------------*");
		System.out.println();
		
		UserInteraction ui=new UserInteraction();
		int ch;
		System.out.println("1.Applicant");
		System.out.println("2.Member of Admission Committee(MAC)");
		
		
		ch=scr.nextInt();
	
	
		switch (ch) {
		case 1:
				//call UserInteraction for user as applicant
			ui.applicantDetails();	
			break;
			

		case 2:
			//call UserInteraction for user as MAC
			ui.MACLogin();
			break;
			
			
			
		default:
			System.out.println("Invalid option!!");
			break;
		}

System.out.println("Hey user, do you want to continue? [y/n]");
choice=scr.next();

//if choice is no LogOut
if(choice.charAt(0)=='n' || choice.charAt(0)=='N')
	{
	System.out.println("--------------------------------------------------------------------------------------------");
	
	System.out.println("Logging Off.....");
	System.out.println("--------------------------------------------------------------------------------------------");
	
	}

	}while(choice.charAt(0)=='y' || choice.charAt(0)=='Y');
  
	}
  

}
