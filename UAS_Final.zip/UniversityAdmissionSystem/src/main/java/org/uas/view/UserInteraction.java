package org.uas.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.uas.model.Application;
import org.uas.model.Participant;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;
import org.uas.model.Status;
import org.uas.service.I_UAS_Service;
import org.uas.service.UAS_Service_Impl;

public class UserInteraction {
	
	I_UAS_Service service=new UAS_Service_Impl();
	Scanner scanner=new Scanner(System.in); 

	//This method deal with the User as Applicant
	public void applicantDetails() throws InvalidMarksException  {

		String str;
	do {
		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("Choose the action you want to do");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		System.out.println("1.View All Programs");
		System.out.println("2.Check your application status");

		int choice;
		
		choice=scanner.nextInt();
		
		
		switch (choice) {
		case 1:
			Application application=new Application();
		
			
			//get list of offered program
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			//get list of scheduled program
			List<ProgramsSchedule> programs_schedule=new ArrayList<>();
			programs_schedule=service.getProgramSchedules();
			
			//Print all programs using offered programs and scheduled program as argument
			Utility.printAllPrograms(programs,programs_schedule);
			String wish;
			
			
			System.out.println("Do you wish to apply?[y|n]");
			wish=scanner.next();
			
			//break out of case:1 if user opt for n/N 
			if(wish.charAt(0)!='y' && wish.charAt(0)!='Y' ) break;
			
			System.out.println("Choose one program ID:");
			boolean pr;
			do {
				pr=false;
				
				int option=scanner.nextInt();
				
				for(ProgramsSchedule program :programs_schedule)
				{
					if(program.getScheduleProgramId()==option)
					{
						application.setScheduledProgramId(program.getScheduleProgramId());
						pr=true;
						break;
						
					}
					
					
				}
				if(!pr) System.out.println("Invalid program ID. Please try Again!");
				
				}while(!pr);
				
				System.out.println("Enter Full Name:");
				scanner.nextLine();
				String name=scanner.nextLine();
				
				//Prompt Full Name
				if(isValidName(name))
				application.setFullName(name);
				else
				{
					boolean flag=true;
					String Name;
					do
					{
					System.out.println("Please enter valid name!");
					

					 Name=scanner.nextLine();
					
					if(!Name.matches("[a-zA-Z]{3,}+"))
					{
						flag=false;
					}
					else
					{
						flag=true;
					}
					
					
					}while(!flag);
					
					application.setFullName(Name);
				}
				
				//Prompt Date of Birth
				System.out.println("Enter date of birth [dd-mm-yyyy]");
			
				String dob=scanner.next();
				String[] dob2;
				if(isValidDob(dob)) {
					String[] dob1=dob.split("-");
				application.setDateOfBirth(LocalDate.of(Integer.parseInt(dob1[2]), Integer.parseInt(dob1[1]), Integer.parseInt(dob1[0])));
				}else
				{
					boolean flag=true;
				
					do
					{
					System.out.println("please enter valid date!");
					
					 dob=scanner.next();
					 dob2=dob.split("-");
					if(!isValidDob(dob))
						flag=false;

					else flag=true;

					}while(!flag);
					
					application.setDateOfBirth(LocalDate.of(Integer.parseInt(dob2[2]), Integer.parseInt(dob2[1]), Integer.parseInt(dob2[0])));

				}
				
				
				//Prompt for Qualification to be one of[10th/12th/UG/PG]
				System.out.println("Enter Highest Qualification [10th/12th/Graduate/PG]");
				String qualify=scanner.next();
				if(verifyQualify(qualify))
				{application.setHighestQualification(qualify);}
				else
				{
					boolean flag=true;
				
					do
					{
					System.out.println("please enter valid qualification!");
					
					 qualify=scanner.next();
					
					if(!verifyQualify(qualify))
						flag=false;
					else
						flag=true;
					
					
					}while(!flag);
					
					application.setHighestQualification(qualify);
					
				}
				
				//Prompt Marks obtained
				System.out.println("Enter marks obtained");
				
				application.setMarksObtained(scanner.nextInt());
				
				
				while(!service.isVAlidMarks(application.getMarksObtained()))
				{
					System.out.println("Invalid marks! Enter marks obtained");
					
					application.setMarksObtained(scanner.nextInt());
				}
				
				//Prompt Goals
				System.out.println("Enter your goals");
				scanner.nextLine();
				application.setGoals(scanner.nextLine());
				
				//Prompt Email Id
				System.out.println("Enter your EmailID");
				String email=scanner.next();
				if(isValidEmail(email))
				application.setEmailId(email);
				else
				{
					boolean flag=true;
					String email1;
					do
					{
					System.out.println("please enter valid email!");
					

					 email1=scanner.next();
					
					if(!isValidEmail(email1))	
						flag=false;
					
					else
					     flag=true;

					}while(!flag);
					
					
					application.setEmailId(email1);
				}
				
				//Fresh applicant status is Applied by default
				application.setStatus(Status.APPLIED);
				
				
				//apply for the corresponding program return type Application Object
				Application application1=service.apply(application);
				
				System.out.println("Application submitted successfully with Applicant ID: \""
						+application1.getApplicationId()+"\" "
								+ "Status:\""+application1.getStatus()+"\"");
				
			
			
			
			break;
		case 2:
			//case to print Status of the applicant based on the applicant Id
			System.out.println("Enter the Applicant Id:");
			int appId=scanner.nextInt();
			
			String status=service.getStatus(appId);
			System.out.println("Your Application is "+status);
			break;
		default:
			System.out.println("Invalid Option!!");
			break;
		}
		System.out.println(" Applicant Do you want to continue? [y/n]");
		str=scanner.next();
	}while(str.charAt(0)=='y' || str.charAt(0)=='Y');
	}

	//Method to validate Email Id
	private boolean isValidEmail(String email) {
		
		String regex = "^[A-Za-z0-9+_.-]+@(.+)$"; 
		 Pattern pattern = Pattern.compile(regex); 
		 Matcher matcher = pattern.matcher((CharSequence)email); 
		 return matcher.matches();
		
		
		
		
	}

	//Method to validate Qualification
	private boolean verifyQualify(String qualify) {
		if(qualify.compareTo("12th")==0 || qualify.compareTo("10th")==0 || (qualify.toUpperCase()).compareTo("UG")==0 || (qualify.toUpperCase()).compareTo("PG")==0)
		return true;
		
		return false;
	}

	//Method to validate Date of birth
	private boolean isValidDob(String dob) {
		String[] date=dob.split("-");
		
		//date of birth between 1950 to 2005
		if(date[2].length()==4 && Integer.parseInt(date[2])<2005 && Integer.parseInt(date[2])>1950)
			if(Integer.parseInt(date[1])>0 && Integer.parseInt(date[1])<12)
				if(Integer.parseInt(date[0])>0 && Integer.parseInt(date[0])<31)
					return true;
		return false;
	}
	
	
	
	//Method to validate Name
	private boolean isValidName(String name) {

		boolean flag=true;
		
		
		if(!name.matches("[a-zA-Z]+"))
		{
			flag=false;
		}
		
		
		return flag;
	}

	//This method deal with the User as the Member of Admission Committee(MAC)
	public void MACLogin() {
		String str;

		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("\t\t****MAC LOGIN****");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		System.out.println("Enter the Username: ");
		int username=scanner.nextInt();
		
		System.out.println("Enter the password:");
		String pwd=scanner.next();
		boolean bool=service.isVAlidLogin(username,pwd);
		do {
			//Continue only if MAC is valid user
		if(bool
				)
		{
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			ProgramsOffered program=new ProgramsOffered();
			
			System.out.println("Enter Program Id: ");
			
			
				int programId=scanner.nextInt();
				
				boolean b=service.isValidProgram(programId);
				if(b)
				{
					System.out.println("Eligibility for the program is: "+service.getEligibilityCriteria(programId));
				List<Application> applications=service.getAllApplicants(programId);
				//System.out.println(applications);
				int cnt=0;
			if(!applications.isEmpty())
			{	
				for(Application application:applications)
				{
					if(application.getStatus().toString()!="REJECTED" && application.getStatus().toString()!="CONFIRMED")
					{
						System.out.println("Applicant ID\t Full Name \t DOB\t\tHighest Qualification\tMarks Obtained\tGoals\tEmail ID\tStatus");
						System.out.println("----------------------------------------------------------------------------------------------------------------------------");
						
			
					System.out.println("\t"+application.getApplicationId()+"\t"+application.getFullName()+"\t\t"+application.getDateOfBirth()+"\t\t"+application.getHighestQualification()+"\t\t2"
							+application.getMarksObtained()+"\t"+application.getGoals()+"\t"+application.getEmailId()+"\t"+application.getStatus());
						if(application.getStatus()==Status.APPLIED)
						{
								System.out.println("1. Accept \n2. Reject");
								int choice=scanner.nextInt();
								switch(choice)
								{
								case 1: System.out.println("Give the date of Interview [dd-mm-yyyy]");	
											String[] date= scanner.next().split("-");
											LocalDate interviewDate=LocalDate.of(Integer.parseInt(date[2]), Integer.parseInt(date[1]), Integer.parseInt(date[0]));
											application.setStatus(Status.ACCEPTED);
											application.setDateOfInterview(interviewDate);
											service.updateApplicationStatus(application);
											break;
								case 2:
										application.setStatus(Status.REJECTED);
										service.updateApplicationStatus(application);
										break;
								default: System.out.println("Invalid choice");
								break;
								
								}
						}
						else if(application.getStatus()==Status.ACCEPTED)
						{
							System.out.println("1. Confirm \n2. Reject");
							int choice=scanner.nextInt();
							switch(choice)
							{
							case 1:		application.setStatus(Status.CONFIRMED);
										
										service.updateApplicationStatus(application);
										
										Participant participant=new Participant();
										participant.setApplication(application);
										participant.setEmailId(application.getEmailId());
										participant.setRollNo(Utility.generatevalue());
										participant.setScheduledProgramId(application.getScheduledProgramId());
										service.createParticipant(participant);
										break;
							case 2:
									application.setStatus(Status.REJECTED);
									service.updateApplicationStatus(application);
									break;
									
							default: System.out.println("Invalid choice!!");
							
							}
						}
						
					}
					else
						cnt++;
				}
				if(cnt>0) System.out.println("No new Applicants to approve!");
				
				
					
		
			
			
		
			}
			else
			
				System.out.println("There are no applicants for this program!");

	
		}
		else
			System.out.println("Program does not exist!");
		
		}
		System.out.println("MAC Do you want to continue?[y/n]");
		str=scanner.next();
	}while(str.charAt(0)=='y' || str.charAt(0)=='Y');
	
		
	
	
	}
	
	
	
	
}
