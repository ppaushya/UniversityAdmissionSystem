package org.uas.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.uas.dao.ApplicationDao;
import org.uas.dao.I_UAS_Dao;
import org.uas.dao.UAS_Dao_Impl;
import org.uas.model.Application;
import org.uas.model.Participant;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;
import org.uas.model.Users;
import org.uas.view.InvalidMarksException;



public class UAS_Service_Impl implements I_UAS_Service{
	final static Logger logger=Logger.getLogger(UAS_Dao_Impl.class);
	
	ApplicationDao appdao=new ApplicationDao(); 
	I_UAS_Dao uasDao=new UAS_Dao_Impl();


	public UAS_Service_Impl(ApplicationDao applicationdao) {
		// TODO Auto-generated constructor stub
		
		this.appdao=applicationdao;
	}

	public UAS_Service_Impl() {
		// TODO Auto-generated constructor stub
	}

	public UAS_Service_Impl(I_UAS_Dao applicationdao) {
		// TODO Auto-generated constructor stub
		this.uasDao=applicationdao;
	}

	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		// TODO Auto-generated method stub
		return uasDao.getAllProgramsOffered();
	}

	@Override
	public String getStatus(int appId) {
		
		return uasDao.getStatus(appId);
	}

	@Override
	public Application apply(Application application) {
		return(uasDao.apply(application));
		
	}

	@Override
	public boolean isVAlidLogin(int username, String pwd) {
		
		List<Users> users= uasDao.getUserDetails();
		//System.out.println(users);
		for(Users user1:users)
		{
			if(user1.getLoginId()==username && user1.getPassword().equals(pwd))
			{
				System.out.println("You are successfully loggedIn");
				return true;
			}
			
			
		}
		System.out.println("invalid");
		return false;
		
	}

	@Override
	public List<Application> getAllApplicants(int programId) {
		return uasDao.getAllApplicants(programId);
		
	}

	@Override
	public boolean updateApplicationStatus(Application application) {
		return ( uasDao.updateApplicationStatus(application));
		
	}

	@Override
	public boolean createParticipant(Participant participant) {
		// TODO Auto-generated method stub
		return(uasDao.createParticipant(participant));
		
	}

	@Override
	public boolean isVAlidMarks(int marksObtained) {
	
		
		try {
				if(marksObtained<0 ||marksObtained>100)
				{
					
					throw new InvalidMarksException("Marks can't be negative or greater than 100");
					 
					
				}
		}
		catch(InvalidMarksException e)
		{
			
			
			logger.error(e.getMessage(),e);
			
			return false;
			//e.printStackTrace();
			
		}
		return true;
	}

	@Override
	public boolean isValidProgram(int programId) {
		
		return uasDao.isValidProgram(programId);
	}

	@Override
	public String getEligibilityCriteria(int programId) {
		
		return uasDao.getEligibilityCriteria(programId);
	}

	@Override
	public List<ProgramsSchedule> getProgramSchedules() {
		// TODO Auto-generated method stub
		return uasDao.getProgramSchedules();
	}

}
