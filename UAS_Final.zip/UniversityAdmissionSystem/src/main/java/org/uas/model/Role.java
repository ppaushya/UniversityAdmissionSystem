package org.uas.model;

public enum Role {

	ADMIN, MAC;
}
