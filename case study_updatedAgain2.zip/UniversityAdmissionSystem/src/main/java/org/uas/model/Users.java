package org.uas.model;

public class Users {
	
	private int loginId;
	private String password;
	private Role role;
	
	
	
	public Users() {
		super();
	}
	public Users(int loginId, String password, Role role) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.role = role;
	}
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Users [loginId=" + loginId + ", password=" + password + ", role=" + role + "]";
	}
	
	

}
