package org.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProgramScheduleDao {
	
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();

	public  boolean isValidProgram(int programId) {

		String sql="select * from programs_scheduled where scheduled_program_id=? ";
		
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			
			pst.setInt(1, programId);
			ResultSet rs=pst.executeQuery();
		
			if(rs.next())
			{
				return true;
			}
			else
			{}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		}
}
