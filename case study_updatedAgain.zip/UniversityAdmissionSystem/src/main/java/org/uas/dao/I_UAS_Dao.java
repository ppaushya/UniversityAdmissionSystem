package org.uas.dao;

import java.util.List;

import org.uas.model.Application;
import org.uas.model.Participant;
import org.uas.model.ProgramsOffered;
import org.uas.model.Users;

public interface I_UAS_Dao {

	public List<ProgramsOffered> getAllProgramsOffered();
	
	public Application apply(Application application);
	public String getStatus(int appId);
	public List<Users> getUserDetails();
	public List<Application> getAllApplicants(int programId);

	public boolean updateApplicationStatus(Application application);

	public boolean createParticipant(Participant participant);
	
}
