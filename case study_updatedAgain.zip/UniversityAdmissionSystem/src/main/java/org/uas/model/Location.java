package org.uas.model;

public class Location {

	private int locationId;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String pincocde;
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincocde() {
		return pincocde;
	}
	public void setPincocde(String pincocde) {
		this.pincocde = pincocde;
	}
	public Location(int locationId, String addressLine1, String addressLine2, String city, String state,
			String pincocde) {
		super();
		this.locationId = locationId;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.pincocde = pincocde;
	}
	
	public Location()
	{
		
	}
	@Override
	public String toString() {
		return "Location [locationId=" + locationId + ", addressLine1=" + addressLine1 + ", addressLine2="
				+ addressLine2 + ", city=" + city + ", state=" + state + ", pincocde=" + pincocde + "]";
	}

}
