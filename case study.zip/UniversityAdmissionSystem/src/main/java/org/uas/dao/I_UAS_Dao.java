package org.uas.dao;

import org.uas.model.Application;
import org.uas.model.ProgramsOffered;

public interface I_UAS_Dao {

	public ProgramsOffered getAllPrograms();
	public Application getAllApplicants();
	
}
