package org.uas.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.uas.dao.UAS_Dao_Impl;
import org.uas.model.ProgramsSchedule;
import org.uas.service.I_UAS_Service;
import org.uas.service.UAS_Service_Impl;

public class UserInteraction {

	public void applicantDetails() {

		I_UAS_Service service=new UAS_Service_Impl();
		
		Scanner scanner=new Scanner(System.in); 
		
		System.out.println("Choose the action you want to do");
		
		System.out.println("1.View All Programs");


		System.out.println("2.Check your application status");

		int choice;
		
		choice=scanner.nextInt();
		
		
		switch (choice) {
		case 1:
			
			List<ProgramsSchedule> programs=new ArrayList<>();
			programs=service.getAllPrograms();
			String option;
			
			System.out.println("Do you want to apply for a program.[y/n]");
			option=scanner.next();
			
			if(option.charAt(0)=='y' || option.charAt(0)=='Y' )
			{
				System.out.println("Choose one program");
				
				//Iterate and print all programs
				//scan program no
				//based on program no get application
			}
			
			
			break;

		default:
			break;
		}
		
		
	}

	
	
	
	
}
