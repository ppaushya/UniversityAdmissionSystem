package org.uas.view;

import java.util.Scanner;

public class BootClass {
	
	static Scanner scr=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Applicant or Admin");
		
		UserInteraction ui=new UserInteraction();
		int ch;
		System.out.println("1.Applicant");
		System.out.println("2.Admin");
		
		ch=scr.nextInt();
		
		switch (ch) {
		case 1:
			
		ui.applicantDetails();	
			

		case 2:
			
			
			
		default:
			break;
		}


	}
  
  
  

}
