package org.uas.model;

import java.time.LocalDate;

public class ProgramsSchedule {

	private int scheduleProgramId;
	private String programName;
	private Location location;
	private LocalDate startDate;
	private LocalDate endDate;
	private int sessionPerWeek;
	public int getScheduleProgramId() {
		return scheduleProgramId;
	}
	public void setScheduleProgramId(int scheduleProgramId) {
		this.scheduleProgramId = scheduleProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public Location getLocationId() {
		return location;
	}
	public void setLocationId(Location location) {
		this.location = location;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public int getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(int sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	public ProgramsSchedule(int scheduleProgramId, String programName, Location location, LocalDate startDate,
			LocalDate endDate, int sessionPerWeek) {
		super();
		this.scheduleProgramId = scheduleProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionPerWeek = sessionPerWeek;
	}
	
	public ProgramsSchedule()
	{
		
	}
	@Override
	public String toString() {
		return "ProgramsSchedule [scheduleProgramId=" + scheduleProgramId + ", programName=" + programName
				+ ", location=" + location + ", startDate=" + startDate + ", endDate=" + endDate + ", sessionPerWeek="
				+ sessionPerWeek + "]";
	}
	
	
}
