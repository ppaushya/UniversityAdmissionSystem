package org.uas.model;

public enum Status {
	

	APPLIED,ACCEPTED,REJECTED,CONFIRMED;

}
