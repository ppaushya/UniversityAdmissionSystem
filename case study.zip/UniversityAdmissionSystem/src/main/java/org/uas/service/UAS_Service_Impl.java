package org.uas.service;

import org.uas.model.Application;
import org.uas.model.ProgramsOffered;

public class UAS_Service_Impl implements I_UAS_Service{

	@Override
	public ProgramsOffered getAllPrograms() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Application getAllApplicants() {
		// TODO Auto-generated method stub
		return null;
	}

}
