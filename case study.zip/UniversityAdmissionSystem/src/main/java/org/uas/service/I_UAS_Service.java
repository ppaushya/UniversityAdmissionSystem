package org.uas.service;

import java.util.List;

import org.uas.model.Application;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;

public interface I_UAS_Service {

	public List<ProgramsSchedule> getAllPrograms();
	public Application getAllApplicants();
	
}
