package org.uas.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;



import org.uas.model.Application;
import org.uas.model.ProgramsOffered;
import org.uas.model.Role;
import org.uas.model.Status;
import org.uas.model.Users;


public class UAS_Dao_Impl implements I_UAS_Dao{

	
	private Connection getConnection() {
		Connection connection = null;
		try {
			
			
		Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/case_study", "root", "India123");
			return connection;
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		List<ProgramsOffered> programs= new ArrayList<>();
		
		String sql="select * from programs_offered";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ProgramsOffered program=new ProgramsOffered();
				program.setProgramName(rs.getString(1));
				program.setDescription(rs.getString(2));
				program.setApplicantEligibility(rs.getString(3));
				program.setDuration(rs.getInt(4));
				program.setDegreeCertificateOffered(rs.getString(5));
				programs.add(program);
				
			}
			return programs;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getStatus(int appId) {
		Application application=new Application();
		String sql="select status from application where application_id=?";
		try(Connection connection=getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
				pst.setInt(1, appId);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					return rs.getString(1);
				}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Application apply(Application application) {
		Application application1=new Application();
		String sql="insert into application(full_name, date_of_birth, highest_qualification, marks_obtained, goals, email_id, status) values(?,?,?,?,?,?,?)";
		try(Connection connection=getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
				pst.setString(1, application.getFullName());
				pst.setDate(2,Date.valueOf(application.getDateOfBirth()));
				pst.setString(3, application.getHighestQualification());
				pst.setInt(4, application.getMarksObtained());
				pst.setString(5, application.getGoals());
				pst.setString(6, application.getEmailId());
				pst.setString(7,application.getStatus().toString());
				
			
			int flag=pst.executeUpdate();
			if(flag>0)
			{
				
				System.out.println("Record inserted successfully");
				String sql1="select application_id, scheduled_program_id, status from application";
				PreparedStatement pst1=connection.prepareStatement(sql1);
				
				ResultSet rs=pst1.executeQuery();
				
				while(rs.next())
				{
					application1.setApplicationId(rs.getInt(1));
					application1.setScheduledProgramId(rs.getInt(2));
					application1.setStatus(Status.valueOf(rs.getString(3)));
					return application1;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	@Override
	public List<Users> getUserDetails() {
		List<Users> users=new ArrayList<>();
		Users user=new Users();
		String sql="select * from users";
		try(Connection connection=getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			
			
				
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					user.setLoginId(rs.getInt(1));
					user.setPassword(rs.getString(2));
					user.setRole(Role.valueOf(rs.getString(3)));
					
					users.add(user);
				}
				return users;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public List<Application> getAllApplicants(int programId) {
		List<Application> applications=new ArrayList<>();
		Application application=new Application();
		String sql="select * from application where scheduled_program_id=? and "
				+ "(date_of_interview is null "
				+ "or date_of_interview <=now())";
		try(Connection connection=getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setInt(1,programId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				application.setApplicationId(rs.getInt(1));
				application.setFullName(rs.getString(2));
				application.setDateOfBirth(rs.getDate(3).toLocalDate());
				application.setHighestQualification(rs.getString(4));
				application.setMarksObtained(rs.getInt(5));
				application.setGoals(rs.getString(6));
				application.setEmailId(rs.getString(7));
				application.setScheduledProgramId(rs.getInt(8));
				application.setStatus(Status.valueOf(rs.getString(9)));
				application.setDateOfInterview(rs.getDate(10).toLocalDate());
				applications.add(application);
			}
			return applications;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	
	
	

}
