package org.uas.dao;

import java.util.List;

import org.uas.model.Application;
import org.uas.model.ProgramsOffered;

public interface I_UAS_Dao {

	public List<ProgramsOffered> getAllProgramsOffered();
	public Application getAllApplicants();
	public int apply(ProgramsOffered program);
	public String getStatus(int appId);
	
}
