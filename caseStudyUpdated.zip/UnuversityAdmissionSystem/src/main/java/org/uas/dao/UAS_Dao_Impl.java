package org.uas.dao;

import java.util.List;

import org.uas.model.Application;
import org.uas.model.ProgramsOffered;

public class UAS_Dao_Impl implements I_UAS_Dao{

	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Application getAllApplicants() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int apply(ProgramsOffered program) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getStatus(int appId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	

}
