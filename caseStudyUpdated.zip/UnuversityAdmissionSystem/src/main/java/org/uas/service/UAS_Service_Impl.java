package org.uas.service;

import java.util.List;

import org.uas.dao.I_UAS_Dao;
import org.uas.dao.UAS_Dao_Impl;
import org.uas.model.Application;
import org.uas.model.ProgramsOffered;

public class UAS_Service_Impl implements I_UAS_Service{
	
	I_UAS_Dao uasDao=new UAS_Dao_Impl();

	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		// TODO Auto-generated method stub
		return uasDao.getAllProgramsOffered();
	}

	@Override
	public Application getAllApplicants() {
		// TODO Auto-generated method stub
		return uasDao.getAllApplicants();
	}

	@Override
	public int apply(ProgramsOffered program) {
		// TODO Auto-generated method stub
		
		return uasDao.apply(program);
	}

	@Override
	public String getStatus(int appId) {
		// TODO Auto-generated method stub
		return uasDao.getStatus(appId);
	}

}
