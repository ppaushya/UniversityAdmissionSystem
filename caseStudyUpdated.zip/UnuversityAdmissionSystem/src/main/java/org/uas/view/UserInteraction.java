package org.uas.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.uas.dao.UAS_Dao_Impl;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;
import org.uas.service.I_UAS_Service;
import org.uas.service.UAS_Service_Impl;

public class UserInteraction {
	
	I_UAS_Service service=new UAS_Service_Impl();
	Scanner scanner=new Scanner(System.in); 

	//This method deal with the User as Applicant
	public void applicantDetails() {

		System.out.println("Choose the action you want to do");
		
		System.out.println("1.View All Programs");
		System.out.println("2.Check your application status");

		int choice;
		
		choice=scanner.nextInt();
		
		
		switch (choice) {
		case 1:
			
		//	List<ProgramsSchedule> programs=new ArrayList<>();
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			ProgramsOffered program=new ProgramsOffered();
			
			
			System.out.println("Do you want to apply for a program.[y/n]");
			String option=scanner.next();
			
			if(option.charAt(0)=='y' || option.charAt(0)=='Y' )
			{
				System.out.println("Choose one program");
				
				//Iterate and print all programs
				//scan program no.
				//based on program no. get application
				
				Utility.printAllPrograms(programs);
			
				int ch=scanner.nextInt();
				int count=1;
				for(ProgramsOffered program1:programs)
				{	if(count==ch)					//this will select the program in the list chosen by applicant
						program=program1;
						
						count++;
				}
				
				//apply for the corresponding program return type int(applicant ID)
				int applicantId=service.apply(program);
				
				System.out.println("Application submitted successfully with Applicant ID:"+applicantId);
				
			}
			
			
			break;
		case 2:
			System.out.println("Enter the Applicant Id:");
			int appId=scanner.nextInt();
			
			String status=service.getStatus(appId);
			System.out.println("Your Application is "+status);
		default:
			break;
		}
		
		
	}

	//This method deal with the User as the Member of Admission Committee(MAC)
	public void MACLogin() {
		
		System.out.println("Enter the Username: ");
		String username=scanner.next();
		
		System.out.println("Enter the password:");
		String pwd=scanner.next();
		
		if(isVAlidLogin(username,pwd))
		{
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			ProgramsOffered program=new ProgramsOffered();
			
			
			System.out.println("Do you want to apply for a program.[y/n]");
			String option=scanner.next();
			
			if(option.charAt(0)=='y' || option.charAt(0)=='Y' )
			{
				System.out.println("Choose one program");
				
				//Iterate and print all programs
				//scan program no.
				//based on program no. get application
				
				Utility.printAllPrograms(programs);
			
				int ch=scanner.nextInt();
				int count=1;
				for(ProgramsOffered program1:programs)
				{	if(count==ch)					//this will select the program in the list chosen by MAC
						program=program1;
						
						count++;
				}
				
					
		}
			
			
		
	}

	
	
	
	
}
