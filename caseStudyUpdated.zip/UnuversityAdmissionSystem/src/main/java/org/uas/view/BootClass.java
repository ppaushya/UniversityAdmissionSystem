package org.uas.view;

import java.util.Scanner;

public class BootClass {
	
	static Scanner scr=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Applicant or Admin");
		
		UserInteraction ui=new UserInteraction();
		int ch;
		System.out.println("1.Applicant");
		System.out.println("2.Member of Admission Committee(MAC)");
		//System.out.println("3.Administration");
		
		ch=scr.nextInt();
		
		switch (ch) {
		case 1:
				
			ui.applicantDetails();	
			break;
			

		case 2:
			ui.MACLogin();
			
			
			
		default:
			break;
		}


	}
  
  
  

}
