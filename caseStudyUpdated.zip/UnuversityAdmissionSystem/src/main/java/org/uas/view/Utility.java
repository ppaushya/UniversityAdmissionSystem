package org.uas.view;

import java.util.List;

import org.uas.model.ProgramsOffered;

public class Utility {

	public static void printAllPrograms(List<ProgramsOffered> programs) {
		

		System.out.println("S.No. \tProgram Title \t\t Duration \t\t Eligibility \t\t Degree Certificate \t\t Description");
		int count=0;
		for(ProgramsOffered program:programs)
		{
			System.out.println(count+".");
			System.out.println(program.getProgramName());
			System.out.println(program.getDuration());
			System.out.println(program.getApplicantEligibility());
			System.out.println(program.getDegreeCertificateOffered());
			System.out.println(program.getDescription());
			
			count++;
		}
		
	}

}
